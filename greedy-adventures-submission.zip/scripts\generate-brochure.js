// Script to generate a valid, readable PDF brochure for Sea View Skydiving
const fs = require('fs');
const path = require('path');

function createPdfContent() {
  const content = [
    'BT',
    '/F1 24 Tf',
    '50 780 Td',
    '(GREEDY ADVENTURES - SEA VIEW SKYDIVING) Tj',
    '/F2 12 Tf',
    '0 -25 Td',
    '(Pattaya Coastal Dropzone, Thailand - Official Information Brochure 2026) Tj',
    '0 -15 Td',
    '([DEMO MATERIAL - Sample Brochure for Assessment Review]) Tj',
    '/F1 16 Tf',
    '0 -35 Td',
    '(1. THE EXPERIENCE) Tj',
    '/F2 11 Tf',
    '0 -20 Td',
    '(Experience the thrill of a lifetime: tandem skydiving from 13,000 feet directly over) Tj',
    '0 -15 Td',
    '(the emerald waters and white sandy coastline of the Gulf of Thailand.) Tj',
    '0 -15 Td',
    '(* Freefall Speed: 200 - 220 km/h for 45 - 60 seconds) Tj',
    '0 -15 Td',
    '(* Canopy Flight: 5 - 7 minutes peaceful glide with 360-degree ocean views) Tj',
    '0 -15 Td',
    '(* Dropzone: USPA-certified facility with 100% safety record) Tj',
    '/F1 16 Tf',
    '0 -35 Td',
    '(2. TIERED PACKAGE BREAKDOWN & PRICING) Tj',
    '/F1 12 Tf',
    '0 -22 Td',
    '(PACKAGE 1: ECO TANDEM SKYDIVE (Jump Only) - 10,500 THB) Tj',
    '/F2 11 Tf',
    '0 -16 Td',
    '(- 13,000-ft tandem jump strapped to USPA-certified instructor) Tj',
    '0 -14 Td',
    '(- Complete safety briefing, harness, and personalized Skydiving Certificate) Tj',
    '/F1 12 Tf',
    '0 -22 Td',
    '(PACKAGE 2: HANDYCAM PRO (Most Popular) - 12,500 THB) Tj',
    '/F2 11 Tf',
    '0 -16 Td',
    '(- Everything in Eco Package) Tj',
    '0 -14 Td',
    '(- Instructor wrist-mounted HD camera capturing wide-angle POV video & 50+ photos) Tj',
    '/F1 12 Tf',
    '0 -22 Td',
    '(PACKAGE 3: VIP SEA VIEW CINE-PACK (Ultimate Value) - 14,000 THB [Was 17,050 THB]) Tj',
    '/F2 11 Tf',
    '0 -16 Td',
    '(- Complete 13,000-ft tandem jump + Instructor wrist handycam) Tj',
    '0 -14 Td',
    '(- DEDICATED OUTSIDE CAMERAMAN flying 360 around you in freefall) Tj',
    '0 -14 Td',
    '(- 4K professionally edited highlight reel + 100+ high-resolution action photos) Tj',
    '/F1 16 Tf',
    '0 -35 Td',
    '(3. SAFETY, HEALTH & ELIGIBILITY REQUIREMENTS) Tj',
    '/F2 11 Tf',
    '0 -20 Td',
    '(* Minimum Age: 10 years old (Under 18 requires parental consent)) Tj',
    '0 -15 Td',
    '(* Weight Limit: Up to 100 kg. Surcharges apply for 95-100 kg.) Tj',
    '0 -15 Td',
    '(* SCUBA Diving: Strictly NO skydiving within 24 hours of scuba diving) Tj',
    '0 -15 Td',
    '(* Alcohol & Drugs: Zero tolerance within 12 hours of jump) Tj',
    '/F1 14 Tf',
    '0 -30 Td',
    '(BOOKINGS & INQUIRIES) Tj',
    '/F2 11 Tf',
    '0 -18 Td',
    '(Official Website: https://greedyadventures.com/sea-view-tandem-skydiving) Tj',
    '0 -15 Td',
    '(Demo Assistant Chatbot powered by Greedy Adventures AI Agent Architecture) Tj',
    'ET'
  ].join('\n');

  const streamLength = Buffer.byteLength(content, 'utf-8');

  const pdf = `%PDF-1.4
1 0 obj
<<
  /Type /Catalog
  /Pages 2 0 R
>>
endobj
2 0 obj
<<
  /Type /Pages
  /Kids [3 0 R]
  /Count 1
>>
endobj
3 0 obj
<<
  /Type /Page
  /Parent 2 0 R
  /MediaBox [0 0 595 842]
  /Resources <<
    /Font <<
      /F1 4 0 R
      /F2 5 0 R
    >>
  >>
  /Contents 6 0 R
>>
endobj
4 0 obj
<<
  /Type /Font
  /Subtype /Type1
  /BaseFont /Helvetica-Bold
>>
endobj
5 0 obj
<<
  /Type /Font
  /Subtype /Type1
  /BaseFont /Helvetica
>>
endobj
6 0 obj
<<
  /Length ${streamLength}
>>
stream
${content}
endstream
endobj
xref
0 7
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000262 00000 n 
0000000341 00000 n 
0000000415 00000 n 
trailer
<<
  /Size 7
  /Root 1 0 R
>>
startxref
${490 + streamLength}
%%EOF
`;

  return Buffer.from(pdf);
}

const outDir = path.join(__dirname, '..', 'public', 'assets', 'brochure');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

const pdfBuffer = createPdfContent();
fs.writeFileSync(path.join(outDir, 'sea-view-skydiving-brochure.pdf'), pdfBuffer);
console.log('Successfully generated valid PDF brochure:', pdfBuffer.length, 'bytes');
